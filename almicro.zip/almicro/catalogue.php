<!DOCTYPE html>
<html lang="en">
<head>
<title>Catalogues</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/about.css">
<link rel="stylesheet" type="text/css" href="styles/about_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Menu Header -->

	<?php  include_once('header.php')  ?>

	
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="index.html">Home</a></li>
								<li>Catalogues</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- About -->

	<div class="about">
		<div class="container">
			<div class="row">
				
			</div>


			<!-- Features -->

	<div class="features">
		<div class="container">

			
		</div>
		
	</div>
	<h2 class="section_title"><center>Products Catalogues</center></h2>
			<div class="row about_row">
			
				<!-- About Item -->
				<div class="col-lg-2 about_col about_col_left">
					<div class="about_item">
						<div class="about_item_image"><img src="certifications/ISO.jpg" alt=""></div>
						<div class="about_item_title"><a href="#">ISO Certification</a></div>
						<hr>
					</div>
				</div>

				<!-- About Item -->
				<div class="col-lg-2 about_col about_col_middle">
					<div class="about_item">
						<div class="about_item_image"><img src="certifications/ce 2018a.jpg" alt=""></div>
						<div class="about_item_title"><a href="#">CE Certification</a></div>
						<hr>
					</div>
				</div>

				<!-- About Item -->
				<div class="col-lg-2 about_col about_col_right">
					<div class="about_item">
						<div class="about_item_image"><img src="certifications/NSIC 001.jpg" alt=""></div>
						<div class="about_item_title"><a href="#">NSIC Certification</a></div>
						<hr>
					</div>
				</div>

				<!-- About Item -->
				<div class="col-lg-2 about_col about_col_middle">
					<div class="about_item">
						<div class="about_item_image"><img src="certifications/vat-registration-certificate.jpg" alt=""></div>
						<div class="about_item_title"><a href="#">VAT Registration Certification</a></div>
						<hr>
					</div>
				</div>

				<!-- About Item -->
				<div class="col-lg-2 about_col about_col_middle">
					<div class="about_item">
						<div class="about_item_image"><img src="certifications/trust-seal-large.jpg" alt=""></div>
						<div class="about_item_title"><a href="#">Indiamart Trust Seal</a></div>
						<hr>
					</div>
				</div>

				<!-- About Item -->
				<div class="col-lg-2 about_col about_col_middle">
					<div class="about_item">
						<div class="about_item_image"><img src="certifications/trust-seal-large.jpg" alt=""></div>
						<div class="about_item_title"><a href="#">Indiamart Trust Seal</a></div>
						<hr>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Feature -

	<div class="feature">
		<div class="feature_background" style="background-image:url(images/courses_background.jpg)"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title">Why Choose Us</h2>
						<div class="section_subtitle"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu. Vestibulum feugiat, sapien ultrices fermentum congue, quam velit venenatis sem</p></div>
					</div>
				</div>
			</div>
			<div class="row feature_row">

				<!-- Feature Content --
				<div class="col-lg-6 feature_col">
					<div class="feature_content">
						<!-- Accordions --
						<div class="accordions">
							
							<div class="elements_accordions">

								<div class="accordion_container">
									<div class="accordion d-flex flex-row align-items-center"><div>Award for Best School 2017</div></div>
									<div class="accordion_panel">
										<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
									</div>
								</div>

								<div class="accordion_container">
									<div class="accordion d-flex flex-row align-items-center active"><div>You’re learning from the best.</div></div>
									<div class="accordion_panel">
										<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
									</div>
								</div>

								<div class="accordion_container">
									<div class="accordion d-flex flex-row align-items-center"><div>Our degrees are recognized worldwide.</div></div>
									<div class="accordion_panel">
										<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
									</div>
								</div>

								<div class="accordion_container">
									<div class="accordion d-flex flex-row align-items-center"><div>We encourage our students to go global.</div></div>
									<div class="accordion_panel">
										<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
									</div>
								</div>

							</div>

						</div>
						<!-- Accordions End --
					</div>
				</div>

				<!-- Feature Video -
				<div class="col-lg-6 feature_col">
					<div class="feature_video d-flex flex-column align-items-center justify-content-center">
						<div class="feature_video_background" style="background-image:url(images/video.jpg)"></div>
						<a class="vimeo feature_video_button" href="https://player.vimeo.com/video/99340873?title=0" title="OH, PORTUGAL - IN 4K - Basti Hansen - Stock Footage">
							<img src="images/play.png" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
--->

	


<!-- Footer -->

<?php  include_once('footer.php') ?>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/about.js"></script>
</body>
</html>