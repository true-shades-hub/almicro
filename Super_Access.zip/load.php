<?php


?>
$(selector)